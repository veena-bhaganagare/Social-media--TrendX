/* ==========================================================================
   TrendX — interests picker logic
   ========================================================================== */

(function () {
  "use strict";

  if (!window.TrendX || !document.getElementById("chip-grid")) return;

  // Wait for Firebase to report who's signed in before building the page.
  TrendX.once(function (user) {
    if (!user) { window.location.href = "index.html"; return; }
    init(user);
  });

  function init(user) {

  // icon, name, category, trending?
  var TOPICS = [
    ["\u2728", "Artificial Intelligence", "Technology", true],
    ["\uD83D\uDCBB", "Technology", "Technology", false],
    ["\uD83D\uDCDD", "Competitive Exams", "Education", true],
    ["\uD83D\uDE80", "Startups & Business", "Career", true],
    ["\uD83C\uDFC6", "Sports", "Lifestyle", true],
    ["\u2695", "Health & Wellness", "Lifestyle", true],
    ["\u2328", "Coding & Software", "Technology", false],
    ["\uD83D\uDD10", "Cybersecurity", "Technology", false],
    ["\uD83D\uDCB0", "Finance & Investing", "Career", true],
    ["\uD83D\uDCC8", "Career Development", "Career", false],
    ["\uD83C\uDF93", "UPSC & Government Exams", "Education", false],
    ["\u2705", "JEE & NEET Preparation", "Education", false],
    ["\uD83D\uDD2D", "Science & Space", "Education", false],
    ["\uD83D\uDCF0", "News & Current Affairs", "Lifestyle", true],
    ["\uD83C\uDFAC", "Entertainment", "Lifestyle", false],
    ["\uD83C\uDFAE", "Gaming", "Lifestyle", false],
    ["\uD83C\uDFB5", "Music", "Lifestyle", false],
    ["\u2708", "Travel", "Lifestyle", false],
    ["\uD83D\uDCD6", "Books & Learning", "Education", false],
    ["\uD83C\uDF31", "Climate & Environment", "Lifestyle", true],
    ["\u26D3", "Blockchain & Web3", "Technology", true],
    ["\uD83E\uDDE0", "Mental Health", "Lifestyle", false]
  ];

  var CATEGORIES = ["All", "Trending", "Education", "Technology", "Career", "Lifestyle"];

  var selected = new Set(user.interests || []);
  var activeCategory = "All";

  var grid = document.getElementById("chip-grid");
  var tabsRow = document.getElementById("tabs-row");
  var searchInput = document.getElementById("search");
  var countEl = document.getElementById("count");
  var continueBtn = document.getElementById("continue");
  var toast = document.getElementById("toast");

  function showToast(msg) {
    toast.textContent = msg;
    toast.classList.add("show");
    clearTimeout(showToast._t);
    showToast._t = setTimeout(function () { toast.classList.remove("show"); }, 2400);
  }

  function renderTabs() {
    tabsRow.innerHTML = "";
    CATEGORIES.forEach(function (cat) {
      var btn = document.createElement("button");
      btn.type = "button";
      btn.className = "cat-tab";
      btn.setAttribute("role", "tab");
      btn.setAttribute("aria-selected", cat === activeCategory ? "true" : "false");
      btn.textContent = cat;
      btn.addEventListener("click", function () {
        activeCategory = cat;
        renderTabs();
        renderGrid();
      });
      tabsRow.appendChild(btn);
    });
  }

  function matchesCategory(topic) {
    if (activeCategory === "All") return true;
    if (activeCategory === "Trending") return topic[3] === true;
    return topic[2] === activeCategory;
  }

  function renderGrid() {
    var query = searchInput.value.trim().toLowerCase();
    grid.innerHTML = "";

    var visible = TOPICS.filter(function (t) {
      return matchesCategory(t) && t[1].toLowerCase().indexOf(query) > -1;
    });

    if (!visible.length) {
      var empty = document.createElement("p");
      empty.className = "empty-note";
      empty.textContent = "No topics match that search.";
      grid.appendChild(empty);
      return;
    }

    visible.forEach(function (topic) {
      var icon = topic[0], name = topic[1], trending = topic[3];
      var card = document.createElement("button");
      card.type = "button";
      card.className = "topic-card";
      var isOn = selected.has(name);
      card.setAttribute("aria-pressed", isOn ? "true" : "false");

      var iconSpan = document.createElement("span");
      iconSpan.className = "ico";
      iconSpan.textContent = icon;

      var labelSpan = document.createElement("span");
      labelSpan.className = "label";
      var nameSpan = document.createElement("span");
      nameSpan.className = "name";
      nameSpan.textContent = name;
      labelSpan.appendChild(nameSpan);
      if (trending) {
        var tag = document.createElement("span");
        tag.className = "tag";
        tag.textContent = "Trending";
        labelSpan.appendChild(tag);
      }

      var dot = document.createElement("span");
      dot.className = "dot";
      dot.textContent = isOn ? "\u2713" : "";

      card.appendChild(iconSpan);
      card.appendChild(labelSpan);
      card.appendChild(dot);

      card.addEventListener("click", function () {
        if (selected.has(name)) selected.delete(name);
        else selected.add(name);
        renderGrid();
        updateCount();
      });

      grid.appendChild(card);
    });
  }

  function updateCount() {
    countEl.textContent = String(selected.size);
    continueBtn.disabled = selected.size < 3;
  }

  function finish(list) {
    continueBtn.disabled = true;
    TrendX.saveInterests(list)
      .then(function () {
        showToast("Saved. Building your feed…");
        setTimeout(function () { window.location.href = "home.html"; }, 500);
      })
      .catch(function (err) {
        showToast(TrendX.friendlyError(err));
        continueBtn.disabled = selected.size < 3;
      });
  }

  document.getElementById("continue").addEventListener("click", function () {
    finish(Array.from(selected));
  });
  document.getElementById("skip").addEventListener("click", function () {
    finish([]);
  });
  searchInput.addEventListener("input", renderGrid);

  renderTabs();
  renderGrid();
  updateCount();
  } // end init()
})();

/* ==========================================================================
   TrendX — auth logic, backed by Firebase Authentication + Firestore

   Requires firebase-app-compat.js, firebase-auth-compat.js,
   firebase-firestore-compat.js and js/firebase-config.js to be loaded
   before this file (see the <head> of index.html / interests.html /
   home.html / dashboard.html).

   User documents live at Firestore collection "users", one doc per
   Firebase Auth uid: { name, email, interests: [], onboarded, createdAt }.
   ========================================================================== */

(function () {
  "use strict";

  if (!window.firebase) {
    console.error("Firebase SDK not found. Check the <script> tags before auth.js.");
    return;
  }

  var auth = firebase.auth();
  var db = firebase.firestore();
  var googleProvider = new firebase.auth.GoogleAuthProvider();

  function userDocRef(uid) { return db.collection("users").doc(uid); }

  function readUserDoc(uid) {
    return userDocRef(uid).get().then(function (snap) {
      return snap.exists ? snap.data() : null;
    });
  }

  function writeUserDoc(uid, data) {
    return userDocRef(uid).set(data, { merge: true });
  }

  function withUid(uid, data) {
    var out = { uid: uid };
    for (var k in data) out[k] = data[k];
    return out;
  }

  // Plain-language text for the Firebase Auth error codes users hit most.
  function friendlyError(err) {
    var map = {
      "auth/email-already-in-use": "An account already exists with that email.",
      "auth/invalid-email": "Enter a valid email address.",
      "auth/weak-password": "Use at least 6 characters.",
      "auth/user-not-found": "No account found with that email.",
      "auth/wrong-password": "Incorrect password.",
      "auth/too-many-requests": "Too many attempts. Try again in a moment.",
      "auth/popup-closed-by-user": "Google sign-in was closed before finishing.",
      "auth/network-request-failed": "Network error. Check your connection and try again."
    };
    return (err && map[err.code]) || (err && err.message) || "Something went wrong. Please try again.";
  }

  function signUp(name, email, password) {
    return auth.createUserWithEmailAndPassword(email, password).then(function (cred) {
      return cred.user.updateProfile({ displayName: name }).then(function () {
        var fresh = {
          name: name,
          email: email.toLowerCase(),
          interests: [],
          onboarded: false,
          createdAt: firebase.firestore.FieldValue.serverTimestamp()
        };
        return writeUserDoc(cred.user.uid, fresh).then(function () {
          return withUid(cred.user.uid, fresh);
        });
      });
    });
  }

  function signIn(email, password) {
    return auth.signInWithEmailAndPassword(email, password).then(function (cred) {
      return readUserDoc(cred.user.uid).then(function (data) {
        return withUid(cred.user.uid, data || { name: email.split("@")[0], email: email, interests: [], onboarded: false });
      });
    });
  }

  function signInWithGoogle() {
    return auth.signInWithPopup(googleProvider).then(function (result) {
      var user = result.user;
      return readUserDoc(user.uid).then(function (data) {
        if (data) return withUid(user.uid, data);
        var fresh = { name: user.displayName || "TrendX user", email: (user.email || "").toLowerCase(), interests: [], onboarded: false };
        return writeUserDoc(user.uid, fresh).then(function () { return withUid(user.uid, fresh); });
      });
    });
  }

  function signOut() { return auth.signOut(); }

  function saveInterests(list) {
    var user = auth.currentUser;
    if (!user) return Promise.reject(new Error("No signed-in user."));
    return writeUserDoc(user.uid, { interests: list, onboarded: true });
  }

  // Fires cb(userData) every time auth state changes; cb(null) when signed out.
  function onAuthChange(cb) {
    return auth.onAuthStateChanged(function (user) {
      if (!user) { cb(null); return; }
      readUserDoc(user.uid).then(function (data) {
        cb(withUid(user.uid, data || { name: user.displayName || "TrendX user", email: user.email, interests: [], onboarded: false }));
      });
    });
  }

  // Same as onAuthChange but fires once and stops listening — handy for
  // pages (interests.html, home.html, dashboard.html) that just need the
  // current user on load rather than an ongoing subscription.
  function once(cb) {
    var unsub = auth.onAuthStateChanged(function (user) {
      unsub();
      if (!user) { cb(null); return; }
      readUserDoc(user.uid).then(function (data) {
        cb(withUid(user.uid, data || { name: user.displayName || "TrendX user", email: user.email, interests: [], onboarded: false }));
      });
    });
  }

  window.TrendX = {
    onAuthChange: onAuthChange,
    once: once,
    signOut: signOut,
    signUp: signUp,
    signIn: signIn,
    signInWithGoogle: signInWithGoogle,
    saveInterests: saveInterests,
    friendlyError: friendlyError
  };

  // ------------------------------------------------------------------
  // Page wiring for index.html (sign in / sign up). Safe no-op elsewhere.
  // ------------------------------------------------------------------
  var formIn = document.getElementById("form-in");
  if (!formIn) return;

  var toast = document.getElementById("toast");
  function showToast(msg) {
    if (!toast) return;
    toast.textContent = msg;
    toast.classList.add("show");
    clearTimeout(showToast._t);
    showToast._t = setTimeout(function () { toast.classList.remove("show"); }, 2800);
  }

  function setError(id, message) {
    var box = document.getElementById("err-" + id);
    var input = document.getElementById(id);
    if (box) box.textContent = message || "";
    if (input) input.classList.toggle("bad", !!message);
  }

  function setBusy(button, on) {
    button.classList.toggle("busy", on);
    button.disabled = on;
  }

  function routeAfterAuth(user) {
    window.location.href = user.onboarded ? "home.html" : "interests.html";
  }

  // If a session already exists (returning visitor), skip the form.
  TrendX.onAuthChange(function (user) { if (user) routeAfterAuth(user); });

  var panelIn = document.getElementById("panel-in");
  var panelUp = document.getElementById("panel-up");
  document.getElementById("go-signup").onclick = function () {
    panelIn.classList.add("hide");
    panelUp.classList.remove("hide");
  };
  document.getElementById("go-signin").onclick = function () {
    panelUp.classList.add("hide");
    panelIn.classList.remove("hide");
  };

  document.querySelectorAll(".toggle-eye").forEach(function (btn) {
    btn.addEventListener("click", function () {
      var input = document.getElementById(btn.dataset.target);
      var hidden = input.type === "password";
      input.type = hidden ? "text" : "password";
      btn.textContent = hidden ? "Hide" : "Show";
    });
  });

  document.getElementById("forgot-link").addEventListener("click", function (e) {
    e.preventDefault();
    var email = document.getElementById("in-email").value.trim();
    if (!email) { showToast("Enter your email above first."); return; }
    auth.sendPasswordResetEmail(email)
      .then(function () { showToast("Password reset email sent to " + email + "."); })
      .catch(function (err) { showToast(friendlyError(err)); });
  });

  var passUp = document.getElementById("up-pass");
  if (passUp) {
    passUp.addEventListener("input", function () {
      var value = this.value;
      var score = 0;
      if (value.length >= 8) score++;
      if (/[a-z]/.test(value) && /[A-Z]/.test(value)) score++;
      if (/\d/.test(value)) score++;
      if (/[^A-Za-z0-9]/.test(value)) score++;
      var bars = document.querySelectorAll("#strength-meter i");
      var colors = ["#D64545", "#E29A2E", "#2F5FFF", "#12875A"];
      bars.forEach(function (bar, i) {
        bar.style.background = value && i < score ? colors[Math.max(score - 1, 0)] : "";
      });
    });
  }

  formIn.addEventListener("submit", function (e) {
    e.preventDefault();
    var email = document.getElementById("in-email").value.trim();
    var pass = document.getElementById("in-pass").value;
    var ok = true;

    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) { setError("in-email", "Enter a valid email address."); ok = false; }
    else setError("in-email", "");
    if (pass.length < 6) { setError("in-pass", "Password must be at least 6 characters."); ok = false; }
    else setError("in-pass", "");
    if (!ok) return;

    var button = formIn.querySelector(".primary-btn");
    setBusy(button, true);
    TrendX.signIn(email, pass)
      .then(function (user) { showToast("Signed in."); routeAfterAuth(user); })
      .catch(function (err) { setError("in-pass", friendlyError(err)); })
      .finally(function () { setBusy(button, false); });
  });

  var formUp = document.getElementById("form-up");
  formUp.addEventListener("submit", function (e) {
    e.preventDefault();
    var name = document.getElementById("up-name").value.trim();
    var email = document.getElementById("up-email").value.trim();
    var pass = document.getElementById("up-pass").value;
    var ok = true;

    if (name.length < 2) { setError("up-name", "Enter your full name."); ok = false; }
    else setError("up-name", "");
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) { setError("up-email", "Enter a valid email address."); ok = false; }
    else setError("up-email", "");
    if (pass.length < 8) { setError("up-pass", "Use at least 8 characters."); ok = false; }
    else setError("up-pass", "");
    if (!ok) return;

    var button = formUp.querySelector(".primary-btn");
    setBusy(button, true);
    TrendX.signUp(name, email, pass)
      .then(function (user) { showToast("Account created. Welcome, " + name.split(" ")[0] + "."); routeAfterAuth(user); })
      .catch(function (err) { setError("up-email", friendlyError(err)); })
      .finally(function () { setBusy(button, false); });
  });

  ["google-in", "google-up"].forEach(function (id) {
    var btn = document.getElementById(id);
    if (!btn) return;
    btn.addEventListener("click", function () {
      TrendX.signInWithGoogle()
        .then(routeAfterAuth)
        .catch(function (err) { showToast(friendlyError(err)); });
    });
  });
})();
